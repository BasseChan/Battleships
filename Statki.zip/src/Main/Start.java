package Main;

import Menu.Wybor_trybu;

public class Start {
    public static void main(String[] args) {

        new Wybor_trybu();

    }
}
