package Rozgrywka.Plansza;

public class Plansza_przeciwnika {
}
