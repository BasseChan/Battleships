package Rozgrywka.Funkcje;

public class Ruch {

}
